# ofxConvexHull

Convex hull implementation for OpenFrameworks based on [Rick Companje's gist](https://gist.github.com/companje/10677337), which in turn is based on [Greg Borenstein's Proccessing implementation](https://github.com/atduskgreg/Processing-Convex-Hull). simple usage:

	vector<ofPoint> getConvexHull(vector<ofPoint> points);
